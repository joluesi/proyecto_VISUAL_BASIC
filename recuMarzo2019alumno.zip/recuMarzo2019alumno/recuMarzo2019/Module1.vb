﻿Module Module1
    'Definir COLECCIÓN de la clase ComprasCliente con clave cod_cliente.

    'Definir COLECCIÓN de la clase Vendedor con clave cod_vendedor.

    'Definir array ComprasMes
    Public comprasMes(4, 1) As Single
    'Definir variables las necesarias  
   
    'Definir función para crear lista de vendedores en Combobox
   

End Module
