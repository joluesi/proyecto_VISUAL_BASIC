﻿Public Class Cliente
    Public Sub New()

    End Sub

    'CREAR CONSTRUCTOR CON ARGUMENTOS

    Private cod_cliente As Integer
    Public Property Pcodcliente() As Integer
        Get
            Return cod_cliente
        End Get
        Set(ByVal value As Integer)
            cod_cliente = value
        End Set
    End Property
    Private cod_vendedorCli As String
    Public Property PcodVendedorCli() As String
        Get
            Return cod_vendedorCli
        End Get
        Set(ByVal value As String)
            cod_vendedorCli = value
        End Set
    End Property
    Private compras_mes As Single
    Public Property Pcompras_mes() As Single
        Get
            Return compras_mes
        End Get
        Set(ByVal value As Single)
            compras_mes = value
        End Set
    End Property
End Class
