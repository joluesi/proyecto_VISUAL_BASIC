﻿Public Class Vendedor
    Public Sub New()

    End Sub

    'CREAR CONSTRUCTOR CON ARGUMENTOS

    Private cod_vendedor As String
    Public Property Pcod_vendedor() As String
        Get
            Return cod_vendedor
        End Get
        Set(ByVal value As String)
            cod_vendedor = value
        End Set
    End Property
    Private zona As String
    Public Property Pzona() As String
        Get
            Return zona
        End Get
        Set(ByVal value As String)
            zona = value
        End Set
    End Property
    Private comision As Single
    Public Property Pcomision() As Single
        Get
            Return comision
        End Get
        Set(ByVal value As Single)
            comision = value
        End Set
    End Property

    
End Class
